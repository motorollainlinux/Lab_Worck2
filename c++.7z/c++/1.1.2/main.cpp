/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <stdio.h>
#include <math.h>

using namespace std;

int main()
{
  int m1, m2, d;    
  double const y = 6.67 ;
  double F;
  cout << "введите массу 1-го объекта";
  cin >> m1;
  cout << "введите массу 2-го объекта";
  cin >> m2;
  cout << "введите диаметр между объектами";
  cin >> d;
  F = y*(m1*m2)/((2/d)*(2/d));
  cout <<"сила взаимного притяжения равна:" << F <<"*10^-11";
  return(0);
}
