/******************************************************************************
                                            
                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <math.h>
#include <stdio.h>
#include <string>

using namespace std;

int main(int argc, char** argv)
{
     int A =0;
     string str,str2;
     cout << "введите угол в градусах\n";
     cin >> A;
     str = to_string(A /= 6.0);
     str2 = str;
     cout <<"ответ в угломерах: " <<str.erase(str.size() - 2)<<"-"<<str2.substr(str2.length()-2, 2);
     return 0;
}
