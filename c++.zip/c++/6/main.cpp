/******************************************************************************

                          Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <math.h>
#include <stdio.h>

using namespace std;

int main()
{
     int n = 64,q = 2;
     long int b[n];
     b[1] = 1;
     b[n] = b[1]*exp(log(q)*(n-1));
     cout << "ответ: " << b[n]<< " рисинок";
}
