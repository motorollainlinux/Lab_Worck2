/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <math.h>
#include <stdio.h>
using namespace std;

int main()
{
    double x1,x2,y1,y2;
    double R =0;
    cout << "введите x1 \n";
    cin >> x1;
    cout << "введите y1 \n";
    cin >> y1;
    cout << "введите x2 \n";
    cin >> x2;
    cout << "введите y2 \n";
    cin >> y2;
    R = sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
    cout << "расстояние между точками равно:" << R;
}
